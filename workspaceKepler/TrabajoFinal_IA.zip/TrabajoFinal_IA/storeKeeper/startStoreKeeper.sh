#!/bin/bash

 ant run
