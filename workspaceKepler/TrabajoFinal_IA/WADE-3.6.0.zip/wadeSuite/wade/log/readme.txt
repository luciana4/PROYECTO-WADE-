------------------------------------------------
README file for the wade/log directory.
------------------------------------------------
	
The wade/log directory is the default location where log files 
produced by WADE components are placed.

This default location can be modified editing the platform-logging.properties
and node-logging.properties files included in the wade/cfg directory. 

