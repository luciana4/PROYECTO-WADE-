package com.tilab.wade.cfa;

public interface AgentStartedListener {
	public void agentStarted(String name);
}
