package com.tilab.wade.cfa;


public interface AgentStartingListener {
	public void agentStarting(String agent);
}
