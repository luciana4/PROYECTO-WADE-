------------------------------------------------
README file for the wade/add-ons directory.
------------------------------------------------
	
The wade/add-ons directory is the location where put the WADE add-ons modules.
